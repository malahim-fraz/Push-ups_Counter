# Pushups Counter 🏋️‍♂️

This is a simple Python project that counts push-ups using your webcam and pose detection.

## Features
- Detects body position
- Counts repetitions
- Simple to use with a webcam

## How to Run

1. Make sure you have Python 3 installed.
2. Install required packages:
   ```
   pip install -r requirements.txt
   ```
3. Run the script:
   ```
   python main.py
   ```

## Requirements
- OpenCV
- Mediapipe
- NumPy
